module.exports=[15789,(e,o,d)=>{}];

//# sourceMappingURL=mettofun1-main__next-internal_server_app_favicon_ico_route_actions_f2a3ee44.js.map