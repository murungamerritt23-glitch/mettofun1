module.exports=[47425,(a,b,c)=>{}];

//# sourceMappingURL=mettofun1-main__next-internal_server_app__not-found_page_actions_b78e6999.js.map