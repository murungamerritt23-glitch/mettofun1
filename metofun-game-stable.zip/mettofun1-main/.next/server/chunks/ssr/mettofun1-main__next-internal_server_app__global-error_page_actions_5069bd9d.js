module.exports=[71196,(a,b,c)=>{}];

//# sourceMappingURL=mettofun1-main__next-internal_server_app__global-error_page_actions_5069bd9d.js.map