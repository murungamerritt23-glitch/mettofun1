module.exports=[6472,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},67790,a=>{"use strict";let b={src:a.i(6472).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=mettofun1-main_src_app_193c71ed._.js.map