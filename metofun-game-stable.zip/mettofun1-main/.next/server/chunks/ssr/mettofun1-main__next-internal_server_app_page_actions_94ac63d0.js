module.exports=[43770,(a,b,c)=>{}];

//# sourceMappingURL=mettofun1-main__next-internal_server_app_page_actions_94ac63d0.js.map