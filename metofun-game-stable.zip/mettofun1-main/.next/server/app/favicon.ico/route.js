var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__81e1fd7e._.js")
R.c("server/chunks/mettofun1-main__next-internal_server_app_favicon_ico_route_actions_f2a3ee44.js")
R.m(36225)
module.exports=R.m(36225).exports
