:HL["/_next/static/chunks/979c9c490c63d85c.css","style"]
0:{"buildId":"jck1-BGuG_mk_e5nPH4ye","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
